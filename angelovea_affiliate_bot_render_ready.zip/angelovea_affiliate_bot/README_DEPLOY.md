# TikTok Affiliate Creator Bot — Render Ready

This package is prepared for deployment on Render.

## What you get

- One web dashboard you can open from your phone.
- 5 TikTok account slots.
- TikTok OAuth scaffold.
- OpenAI image generation.
- 6 editable prompt presets.
- Product image extraction where public access is allowed.
- Caption generation.
- Google Flow hand-off.
- TikTok Direct Post scaffold.

## Fast deployment with Render

### 1. Create a GitHub repository
Create a new GitHub repository, for example:

`tiktok-affiliate-bot`

Upload all files from this project into that repository.

### 2. Create a Render Web Service
In Render:

- New → Web Service
- Connect your GitHub repository
- Runtime: Python
- Build command:

`pip install -r requirements.txt`

- Start command:

`uvicorn app:app --host 0.0.0.0 --port $PORT`

Render can also read the included `render.yaml`.

### 3. Add environment variables

At minimum for AI image generation:

- `OPENAI_API_KEY`
- `OPENAI_IMAGE_MODEL=gpt-image-2`

For TikTok account login/posting:

- `TIKTOK_CLIENT_KEY`
- `TIKTOK_CLIENT_SECRET`
- `TIKTOK_REDIRECT_URI`
- `TIKTOK_SCOPES=user.info.basic,video.publish`

Set `TIKTOK_REDIRECT_URI` to:

`https://YOUR-RENDER-DOMAIN.onrender.com/api/tiktok/callback`

Then add the same redirect URI inside your TikTok Developer App configuration.

### 4. Deploy

Click Deploy.

Render will give you a public link similar to:

`https://tiktok-affiliate-creator-bot.onrender.com`

That becomes your direct bot link.

## Important

The bot cannot log into TikTok using your username/password. It should use official OAuth.

Google Flow remains a hand-off step unless your Google account has an official automation interface available.

Do not put API keys directly in the code. Add them only in Render Environment Variables.
