# TikTok Affiliate Creator Bot v2

This version upgrades the first dashboard with a real **TikTok OAuth + Content Posting API scaffold**.

## Working pieces

- 5 TikTok account slots.
- Official TikTok Login Kit OAuth flow.
- Server-side TikTok access/refresh-token storage for this local MVP.
- Creator-info query before posting, so the UI can display privacy levels TikTok actually permits.
- Direct-post initialization from an HTTPS video URL on a TikTok-verified domain/prefix.
- Explicit user confirmation before every post.
- `is_aigc` support for AI-generated-video labeling.
- Product metadata/image retrieval from public pages where permitted.
- Six editable prompt presets.
- OpenAI image generation when `OPENAI_API_KEY` is configured.
- Caption generation.
- Google Flow manual hand-off.

## Setup

```bash
python -m venv .venv
```

Activate the environment, then:

```bash
pip install -r requirements.txt
```

Copy `.env.example` to `.env`.

Add your OpenAI API key and TikTok developer-app credentials.

For TikTok Web Login Kit, your registered callback must match `TIKTOK_REDIRECT_URI`. TikTok's web Login Kit requires an HTTPS, absolute, static redirect URI.

Run:

```bash
uvicorn app:app --reload
```

Then open `http://127.0.0.1:8000`.

## TikTok requirements

In TikTok for Developers:

1. Create an app.
2. Add Login Kit.
3. Add Content Posting API.
4. Request/obtain the `video.publish` scope as required.
5. Register your redirect URI.
6. For `PULL_FROM_URL`, verify ownership of the domain or URL prefix that hosts your generated videos.
7. Complete TikTok's audit if you need public posting; unaudited clients can be subject to private-post restrictions.

## Important

Google Flow is not reverse-engineered here. The app opens Flow and prepares the prompt/image workflow, rather than automating the website with saved credentials.

This MVP stores TikTok tokens in a local SQLite database. Before public deployment, encrypt tokens, add app-level authentication, CSRF/session hardening, HTTPS, backups and a proper secret manager.
